from __future__ import annotations

from datetime import timedelta
from decimal import Decimal
import re

from sqlalchemy import Select, select
from sqlalchemy.orm import Session

from app.config import settings
from app.models import BankTransaction, Deal, DealStatus, MatchDecision, TransactionDirection
from app.services.classification import classify_deal_status
from app.schemas import MatchRunResult


def normalize_name(value: str | None) -> str:
    if not value:
        return ""
    return re.sub(r"\s+", " ", value.strip().lower())


def wallet_side(deal: Deal) -> str | None:
    raw_payload = deal.raw_payload or {}
    explicit_side = str(raw_payload.get("side") or "").strip().lower()
    if explicit_side in {"buy", "sell"}:
        return explicit_side

    ad_type = str(raw_payload.get("ad_type") or "").strip().lower()
    role = str(raw_payload.get("role") or "").strip().lower()
    combined = f"{ad_type} {role}"
    if any(token in combined for token in ("buy", "purchase", "buyer", "покуп")):
        return "buy"
    if any(token in combined for token in ("sell", "sale", "seller", "прод")):
        return "sell"
    return None


def expected_bank_direction(deal: Deal) -> TransactionDirection:
    side = wallet_side(deal)
    if side == "buy":
        return TransactionDirection.outgoing
    return TransactionDirection.incoming


def reference_timestamp(deal: Deal):
    return deal.completed_at or deal.opened_at


def reference_tokens(deal: Deal) -> list[str]:
    raw_payload = deal.raw_payload or {}
    tokens = [str(deal.external_id or "").strip()]
    ad_number = str(raw_payload.get("ad_number") or "").strip()
    if ad_number:
        tokens.append(ad_number)
    return [token.lower() for token in tokens if token]


def reference_text(transaction: BankTransaction) -> str:
    parts = [
        transaction.reference or "",
        str((transaction.raw_payload or {}).get("paymentPurpose") or ""),
        str((transaction.raw_payload or {}).get("number") or ""),
    ]
    return " ".join(part.strip().lower() for part in parts if part).strip()


def _candidate_transactions_query(deal: Deal) -> Select[tuple[BankTransaction]]:
    amount_tolerance = Decimal(str(settings.match_amount_tolerance))
    min_amount = deal.expected_fiat_amount - amount_tolerance
    max_amount = deal.expected_fiat_amount + amount_tolerance
    query = select(BankTransaction).where(
        BankTransaction.deal_id.is_(None),
        BankTransaction.currency == deal.fiat_currency,
        BankTransaction.direction == expected_bank_direction(deal),
        BankTransaction.amount >= min_amount,
        BankTransaction.amount <= max_amount,
    )
    deal_reference_dt = reference_timestamp(deal)
    if deal_reference_dt:
        window = timedelta(hours=settings.match_window_hours)
        query = query.where(
            BankTransaction.booked_at >= deal_reference_dt - window,
            BankTransaction.booked_at <= deal_reference_dt + window,
        )
    return query.order_by(BankTransaction.booked_at.asc())


def score_candidate(deal: Deal, transaction: BankTransaction) -> tuple[int, dict]:
    score = 0
    rule_hits: dict[str, object] = {
        "amount_exact": False,
        "name_match": False,
        "same_day_window": False,
        "reference_order_match": False,
        "third_party_risk": False,
        "has_counterparty_name": bool(deal.counterparty_name),
        "delta_minutes": None,
    }

    if transaction.amount == deal.expected_fiat_amount:
        score += 70
        rule_hits["amount_exact"] = True

    deal_reference_dt = reference_timestamp(deal)
    if deal_reference_dt:
        delta = abs(transaction.booked_at - deal_reference_dt)
        delta_minutes = int(delta.total_seconds() // 60)
        rule_hits["delta_minutes"] = delta_minutes
        if delta <= timedelta(hours=24):
            rule_hits["same_day_window"] = True
            score += max(1, 25 - min(delta_minutes // 30, 24))

    transaction_reference = reference_text(transaction)
    if transaction_reference:
        if any(token in transaction_reference for token in reference_tokens(deal)):
            score += 50
            rule_hits["reference_order_match"] = True

    deal_name = normalize_name(deal.counterparty_name)
    payer_name = normalize_name(transaction.payer_name)
    if deal_name and payer_name:
        if deal_name in payer_name or payer_name in deal_name:
            score += 10
            rule_hits["name_match"] = True
        else:
            rule_hits["third_party_risk"] = True

    return score, rule_hits


def run_matching(session: Session) -> list[MatchRunResult]:
    deals = session.scalars(
        select(Deal).where(
            Deal.status.in_(
                [
                    DealStatus.detected,
                    DealStatus.awaiting_payment,
                    DealStatus.matched,
                    DealStatus.receipted,
                    DealStatus.third_party_review,
                    DealStatus.return_detected,
                ]
            )
        )
    ).all()

    results: list[MatchRunResult] = []
    for deal in deals:
        candidates = session.scalars(_candidate_transactions_query(deal)).all()
        if not candidates:
            results.append(
                MatchRunResult(
                    deal_external_id=deal.external_id,
                    score=0,
                    outcome="no_candidate",
                    rule_hits={},
                )
            )
            continue

        best_transaction: BankTransaction | None = None
        best_score = -1
        best_rules: dict = {}
        scored_candidates: list[tuple[BankTransaction, int, dict]] = []
        for candidate in candidates:
            score, rule_hits = score_candidate(deal, candidate)
            scored_candidates.append((candidate, score, rule_hits))
            if score > best_score:
                best_score = score
                best_transaction = candidate
                best_rules = rule_hits

        if best_transaction is None:
            continue

        resolved_by_closest_time = False
        top_candidates = [(candidate, score, rules) for candidate, score, rules in scored_candidates if score == best_score]
        if len(top_candidates) > 1:
            top_candidates.sort(key=lambda item: item[2].get("delta_minutes") if item[2].get("delta_minutes") is not None else 10**9)
            first_delta = top_candidates[0][2].get("delta_minutes")
            second_delta = top_candidates[1][2].get("delta_minutes")
            if first_delta is not None and second_delta is not None and first_delta + 15 < second_delta:
                best_transaction, best_score, best_rules = top_candidates[0]
                resolved_by_closest_time = True

        best_score_count = sum(1 for _, score, _ in scored_candidates if score == best_score)
        best_rules["candidate_count"] = len(scored_candidates)
        best_rules["best_score_count"] = best_score_count
        best_rules["resolved_by_closest_time"] = resolved_by_closest_time
        ambiguous_amount_only = (
            best_score >= 70
            and best_score_count > 1
            and not best_rules.get("name_match")
            and not best_rules.get("reference_order_match")
            and not resolved_by_closest_time
        )

        if best_rules.get("third_party_risk"):
            deal.status = DealStatus.third_party_review
            outcome = "third_party_risk"
        elif ambiguous_amount_only:
            outcome = "ambiguous_amount_only"
        elif best_score >= 70:
            best_transaction.deal_id = deal.id
            deal.status = DealStatus.matched
            outcome = "matched"
        else:
            outcome = "weak_match"

        classify_deal_status(deal)

        session.add(
            MatchDecision(
                deal_id=deal.id,
                bank_transaction_id=best_transaction.id,
                score=best_score,
                outcome=outcome,
                rule_hits=best_rules,
            )
        )

        results.append(
            MatchRunResult(
                deal_external_id=deal.external_id,
                bank_transaction_external_id=best_transaction.external_id,
                score=best_score,
                outcome=outcome,
                rule_hits=best_rules,
            )
        )

    session.commit()
    return results
