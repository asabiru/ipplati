from __future__ import annotations

from datetime import date
from decimal import Decimal

from app.schemas import DealOut, TelegramDashboardSnapshot, WalletProfitStats, WalletRateStats


def _money(value: Decimal) -> str:
    return f"{value:,.2f}".replace(",", " ")


def _decimal_from_raw(value) -> Decimal | None:
    if value in (None, ""):
        return None
    text = str(value).replace("\u00a0", " ").replace(" ", "").replace(",", ".").strip()
    if not text:
        return None
    try:
        return Decimal(text)
    except Exception:
        return None


def _wallet_side_label(raw_payload: dict) -> str:
    explicit_side = str(raw_payload.get("side") or "").strip().lower()
    if explicit_side in {"buy", "sell"}:
        return explicit_side

    ad_type = str(raw_payload.get("ad_type") or "").strip().lower()
    role = str(raw_payload.get("role") or "").strip().lower()
    combined = f"{ad_type} {role}"
    if any(token in combined for token in ("buy", "purchase", "buyer", "?????")):
        return "buy"
    if any(token in combined for token in ("sell", "sale", "seller", "????")):
        return "sell"
    return "n/a"


def _format_rate(value: Decimal | None) -> str:
    if value is None:
        return "-"
    return f"{value:,.2f}".replace(",", " ")


def _format_wallet_rate_stats(title: str, stats: WalletRateStats) -> list[str]:
    lines = [f"<b>{title}</b>"]
    if stats.completed_deals_with_rates == 0:
        lines.append("Нет завершенных сделок с курсом.")
        return lines
    currency = stats.crypto_currency or "crypto"
    lines.extend(
        [
            f"Сделок: <b>{stats.completed_deals_with_rates}</b>",
            f"Fiat: <b>{_money(stats.total_fiat_amount)}</b> RUB",
            f"Net {currency}: <b>{stats.total_net_crypto_amount}</b>",
            f"Fee {currency}: <b>{stats.total_fee_crypto_amount}</b>",
            f"Средний курс по сделкам: <b>{_format_rate(stats.weighted_listed_rate)}</b>",
            f"Чистый сред без комиссии: <b>{_format_rate(stats.weighted_net_rate)}</b>",
        ]
    )
    return lines


def _format_wallet_profit_stats(stats: WalletProfitStats) -> list[str]:
    lines = ["<b>Заработок</b>"]
    currency = stats.crypto_currency or "crypto"
    if stats.matched_crypto_amount <= 0:
        lines.append("Недостаточно перекрытого объема между покупками и продажами.")
        return lines

    lines.extend(
        [
            f"Зафиксированная прибыль: <b>{_money(stats.estimated_profit_rub)}</b> RUB",
            f"Перекрытый объем: <b>{stats.matched_crypto_amount}</b> {currency}",
            f"Чистый buy курс: <b>{_format_rate(stats.avg_buy_net_rate)}</b>",
            f"Чистый sell курс: <b>{_format_rate(stats.avg_sell_net_rate)}</b>",
            f"Спред на 1 {currency}: <b>{_format_rate(stats.spread_per_crypto)}</b>",
            f"Остаток позиции: <b>{stats.inventory_delta_crypto_amount}</b> {currency}",
            f"Денежный поток sell-buy: <b>{_money(stats.cash_flow_delta_rub)}</b> RUB",
        ]
    )
    return lines


def format_summary(snapshot: TelegramDashboardSnapshot) -> str:
    summary = snapshot.summary
    if snapshot.date_from and snapshot.date_to:
        period = f"{snapshot.date_from.isoformat()} - {snapshot.date_to.isoformat()}"
    else:
        period = "все время"
    lines = [
        "<b>Статистика по автоматике</b>",
        "",
        f"Период: <b>{period}</b>",
        f"Сделок всего: <b>{summary.total_deals}</b>",
        f"Сопоставлено с банком: <b>{summary.matched_deals}</b>",
        f"С чеком: <b>{summary.receipted_deals}</b>",
        f"Возвратных: <b>{summary.return_detected_deals}</b>",
        f"На проверке 3-х лиц: <b>{summary.third_party_review_deals}</b>",
        f"Не привязанных платежей: <b>{summary.unmatched_bank_transactions}</b>",
        "",
        f"Ожидаемая сумма, RUB: <b>{_money(summary.total_expected_rub)}</b>",
        f"Получено, RUB: <b>{_money(summary.total_received_rub)}</b>",
        f"Возвратов, RUB: <b>{_money(summary.total_returned_rub)}</b>",
        "",
        f"Банковских операций: <b>{snapshot.total_bank_transactions}</b>",
        f"Чеков всего: <b>{snapshot.total_receipts}</b>",
        f"Чеков продаж: <b>{snapshot.sale_receipts}</b>",
        f"Чеков возврата: <b>{snapshot.refund_receipts}</b>",
    ]
    lines.extend([""])
    lines.extend(_format_wallet_rate_stats("Wallet: общий курс", snapshot.wallet_rate_stats))
    lines.extend([""])
    lines.extend(_format_wallet_rate_stats("Wallet: покупки", snapshot.wallet_buy_rate_stats))
    lines.extend([""])
    lines.extend(_format_wallet_rate_stats("Wallet: продажи", snapshot.wallet_sell_rate_stats))
    lines.extend([""])
    lines.extend(_format_wallet_profit_stats(snapshot.wallet_profit_stats))
    lines.extend(["", f"<b>Wallet CSV</b>", snapshot.wallet_csv_message])
    if not snapshot.wallet_csv_has_coverage:
        lines.append("Пришлите сюда CSV-файл из TG Wallet за нужный период.")
    if snapshot.status_counts:
        lines.extend(["", "<b>Статусы сделок</b>"])
        for status, count in sorted(snapshot.status_counts.items()):
            lines.append(f"{status}: <b>{count}</b>")
    return "\n".join(lines)


def format_recent_deals(deals: list[DealOut]) -> str:
    lines = ["<b>Последние сделки</b>", ""]
    if not deals:
        lines.append("Сделок пока нет.")
        return "\n".join(lines)
    for deal in deals:
        raw_payload = deal.raw_payload or {}
        net_crypto = _decimal_from_raw(raw_payload.get("net_crypto_amount"))
        fee_crypto = _decimal_from_raw(raw_payload.get("paid_fee_crypto_amount")) or Decimal("0")
        listed_rate = _decimal_from_raw(raw_payload.get("price"))
        net_rate = None
        if net_crypto and net_crypto > 0:
            net_rate = deal.expected_fiat_amount / net_crypto
        crypto_currency = raw_payload.get("crypto_currency") or "crypto"
        side = _wallet_side_label(raw_payload)
        lines.append(
            f"{deal.external_id} | {side} | {deal.status.value} | {deal.expected_fiat_amount} {deal.fiat_currency}"
        )
        lines.append(
            f"курс: { _format_rate(listed_rate) } | чистый курс: { _format_rate(net_rate) } | "
            f"net: {net_crypto or '-'} {crypto_currency} | fee: {fee_crypto} {crypto_currency}"
        )
    return "\n".join(lines)


def format_returns(snapshot: TelegramDashboardSnapshot) -> str:
    if snapshot.date_from and snapshot.date_to:
        period = f"{snapshot.date_from.isoformat()} - {snapshot.date_to.isoformat()}"
    else:
        period = "все время"
    lines = [
        "<b>Возвраты и риски</b>",
        "",
        f"Период: <b>{period}</b>",
        f"Возвратных сделок: <b>{snapshot.summary.return_detected_deals}</b>",
        f"Сумма возвратов, RUB: <b>{_money(snapshot.summary.total_returned_rub)}</b>",
        f"Сделок на проверке 3-х лиц: <b>{snapshot.summary.third_party_review_deals}</b>",
        f"Чеков возврата: <b>{snapshot.refund_receipts}</b>",
        "",
        f"Чистый сред общий: <b>{_format_rate(snapshot.wallet_rate_stats.weighted_net_rate)}</b>",
        f"Чистый сред buy: <b>{_format_rate(snapshot.wallet_buy_rate_stats.weighted_net_rate)}</b>",
        f"Чистый сред sell: <b>{_format_rate(snapshot.wallet_sell_rate_stats.weighted_net_rate)}</b>",
        f"Зафиксированная прибыль: <b>{_money(snapshot.wallet_profit_stats.estimated_profit_rub)}</b> RUB",
        f"Перекрытый объем: <b>{snapshot.wallet_profit_stats.matched_crypto_amount}</b> {snapshot.wallet_profit_stats.crypto_currency or 'crypto'}",
        "",
        f"Wallet CSV: {snapshot.wallet_csv_message}",
    ]
    if not snapshot.wallet_csv_has_coverage:
        lines.append("Пришлите сюда CSV-файл из TG Wallet за нужный период.")
    return "\n".join(lines)


def format_help() -> str:
    return "\n".join(
        [
            "<b>Команды бота</b>",
            "",
            "/report - общий отчет",
            "/deals - последние сделки",
            "/returns - возвраты и риски",
            "/help - список команд",
        ]
    )


def format_custom_date_prompt() -> str:
    return "\n".join(
        [
            "<b>Фильтр по датам</b>",
            "",
            "Отправьте диапазон в одном сообщении.",
            "Формат: <code>2026-05-01 2026-05-31</code>",
            "Или: <code>2026-05-01..2026-05-31</code>",
        ]
    )


def format_invalid_date_prompt() -> str:
    return "\n".join(
        [
            "Не удалось распознать даты.",
            "Отправьте диапазон так: <code>2026-05-01 2026-05-31</code>",
        ]
    )


def format_wallet_csv_import_result(
    *,
    filename: str,
    processed_rows: int,
    report: dict,
) -> str:
    lines = [
        "<b>CSV из TG Wallet загружен</b>",
        "",
        f"Файл: <b>{filename}</b>",
        f"Обработано ордеров: <b>{processed_rows}</b>",
        "Учет идет по <b>Order Number</b>, поэтому уже существующие ордера не дублируются, а обновляются.",
        "",
        f"Сделок всего: <b>{report.get('total_deals', 0)}</b>",
        f"Сматчено с банком: <b>{report.get('matched_deals', 0)}</b>",
        f"С чеком: <b>{report.get('receipted_deals', 0)}</b>",
        f"Непривязанных платежей: <b>{report.get('unmatched_bank_transactions', 0)}</b>",
    ]
    return "\n".join(lines)


def format_period_label(date_from: date | None, date_to: date | None) -> str:
    if date_from and date_to:
        return f"{date_from.isoformat()} - {date_to.isoformat()}"
    return "все время"
