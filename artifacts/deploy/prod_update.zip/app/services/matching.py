from __future__ import annotations

from datetime import timedelta
from decimal import Decimal
import re

from sqlalchemy import Select, select
from sqlalchemy.orm import Session

from app.config import settings
from app.models import BankTransaction, Deal, DealStatus, MatchDecision, TransactionDirection
from app.services.classification import classify_deal_status
from app.schemas import MatchRunResult


def normalize_name(value: str | None) -> str:
    if not value:
        return ""
    return re.sub(r"\s+", " ", value.strip().lower())


def _candidate_transactions_query(deal: Deal) -> Select[tuple[BankTransaction]]:
    amount_tolerance = Decimal(str(settings.match_amount_tolerance))
    min_amount = deal.expected_fiat_amount - amount_tolerance
    max_amount = deal.expected_fiat_amount + amount_tolerance
    query = select(BankTransaction).where(
        BankTransaction.deal_id.is_(None),
        BankTransaction.currency == deal.fiat_currency,
        BankTransaction.direction == TransactionDirection.incoming,
        BankTransaction.amount >= min_amount,
        BankTransaction.amount <= max_amount,
    )
    if deal.opened_at:
        window = timedelta(hours=settings.match_window_hours)
        query = query.where(
            BankTransaction.booked_at >= deal.opened_at - window,
            BankTransaction.booked_at <= deal.opened_at + window,
        )
    return query.order_by(BankTransaction.booked_at.asc())


def score_candidate(deal: Deal, transaction: BankTransaction) -> tuple[int, dict]:
    score = 0
    rule_hits: dict[str, object] = {
        "amount_exact": False,
        "name_match": False,
        "same_day_window": False,
        "third_party_risk": False,
        "has_counterparty_name": bool(deal.counterparty_name),
    }

    if transaction.amount == deal.expected_fiat_amount:
        score += 70
        rule_hits["amount_exact"] = True

    if deal.opened_at:
        delta = abs(transaction.booked_at - deal.opened_at)
        if delta <= timedelta(hours=24):
            score += 20
            rule_hits["same_day_window"] = True

    deal_name = normalize_name(deal.counterparty_name)
    payer_name = normalize_name(transaction.payer_name)
    if deal_name and payer_name:
        if deal_name in payer_name or payer_name in deal_name:
            score += 10
            rule_hits["name_match"] = True
        else:
            rule_hits["third_party_risk"] = True

    return score, rule_hits


def run_matching(session: Session) -> list[MatchRunResult]:
    deals = session.scalars(
        select(Deal).where(
            Deal.status.in_(
                [
                    DealStatus.detected,
                    DealStatus.awaiting_payment,
                    DealStatus.matched,
                    DealStatus.receipted,
                    DealStatus.third_party_review,
                    DealStatus.return_detected,
                ]
            )
        )
    ).all()

    results: list[MatchRunResult] = []
    for deal in deals:
        candidates = session.scalars(_candidate_transactions_query(deal)).all()
        if not candidates:
            results.append(
                MatchRunResult(
                    deal_external_id=deal.external_id,
                    score=0,
                    outcome="no_candidate",
                    rule_hits={},
                )
            )
            continue

        best_transaction: BankTransaction | None = None
        best_score = -1
        best_rules: dict = {}
        scored_candidates: list[tuple[BankTransaction, int, dict]] = []
        for candidate in candidates:
            score, rule_hits = score_candidate(deal, candidate)
            scored_candidates.append((candidate, score, rule_hits))
            if score > best_score:
                best_score = score
                best_transaction = candidate
                best_rules = rule_hits

        if best_transaction is None:
            continue

        best_score_count = sum(1 for _, score, _ in scored_candidates if score == best_score)
        best_rules["candidate_count"] = len(scored_candidates)
        best_rules["best_score_count"] = best_score_count
        ambiguous_amount_only = (
            best_score >= 70
            and best_score_count > 1
            and not best_rules.get("name_match")
        )

        if best_rules.get("third_party_risk"):
            deal.status = DealStatus.third_party_review
            outcome = "third_party_risk"
        elif ambiguous_amount_only:
            outcome = "ambiguous_amount_only"
        elif best_score >= 70:
            best_transaction.deal_id = deal.id
            deal.status = DealStatus.matched
            outcome = "matched"
        else:
            outcome = "weak_match"

        classify_deal_status(deal)

        session.add(
            MatchDecision(
                deal_id=deal.id,
                bank_transaction_id=best_transaction.id,
                score=best_score,
                outcome=outcome,
                rule_hits=best_rules,
            )
        )

        results.append(
            MatchRunResult(
                deal_external_id=deal.external_id,
                bank_transaction_external_id=best_transaction.external_id,
                score=best_score,
                outcome=outcome,
                rule_hits=best_rules,
            )
        )

    session.commit()
    return results
