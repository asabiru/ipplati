from __future__ import annotations

from datetime import timedelta
from math import inf

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Deal, DealStatus, FiscalReceipt, ReceiptStatus, ReceiptType
from app.services.classification import classify_deal_status


def _reference_dt(deal: Deal):
    return deal.completed_at or deal.opened_at


def _candidate_rank(receipt: FiscalReceipt, deal: Deal) -> tuple[int, float]:
    reference_dt = _reference_dt(deal)
    delta_seconds = abs((reference_dt - receipt.issued_at).total_seconds()) if reference_dt else inf
    status_priority = 0 if deal.status in {DealStatus.matched, DealStatus.receipted} else 1
    return (status_priority, delta_seconds)


def reconcile_receipts(session: Session, window_hours: int = 24) -> int:
    receipts = session.scalars(select(FiscalReceipt).where(FiscalReceipt.deal_id.is_(None))).all()
    linked = 0
    for receipt in receipts:
        query = select(Deal).where(Deal.fiat_currency == "RUB", Deal.expected_fiat_amount == receipt.amount)
        window = timedelta(hours=window_hours)
        query = query.where(
            Deal.opened_at.is_not(None),
            Deal.opened_at >= receipt.issued_at - window,
            Deal.opened_at <= receipt.issued_at + window,
        ).order_by(Deal.opened_at.asc())

        candidates = session.scalars(query).all()
        if not candidates:
            continue

        ranked_candidates = sorted(candidates, key=lambda deal: _candidate_rank(receipt, deal))
        best_candidate = ranked_candidates[0]
        if len(ranked_candidates) > 1 and _candidate_rank(receipt, ranked_candidates[1]) == _candidate_rank(
            receipt, best_candidate
        ):
            continue

        candidates = [best_candidate]
        for deal in candidates:
            if receipt.receipt_type == ReceiptType.sale and deal.status not in {
                DealStatus.canceled,
                DealStatus.return_detected,
            }:
                receipt.deal_id = deal.id
                deal.status = DealStatus.receipted if receipt.status == ReceiptStatus.issued else deal.status
                classify_deal_status(deal)
                linked += 1
                break

            if receipt.receipt_type == ReceiptType.refund:
                receipt.deal_id = deal.id
                deal.status = DealStatus.return_detected
                deal.return_reason = deal.return_reason or "refund_receipt_auto_match"
                classify_deal_status(deal)
                linked += 1
                break

    session.commit()
    return linked
