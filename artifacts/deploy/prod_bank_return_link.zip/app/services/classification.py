from __future__ import annotations

from datetime import datetime, timezone
from datetime import timedelta
import re

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import BankTransaction, Deal, DealStatus, FiscalReceipt, ReceiptStatus, ReceiptType, TransactionDirection


RETURN_UI_STATUSES = {
    "refund",
    "refunded",
    "returned",
    "reversed",
    "chargeback",
    "return_detected",
}

REVIEW_UI_STATUSES = {
    "disputed",
    "third_party_review",
}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _normalize_name(value: str | None) -> str:
    if not value:
        return ""
    normalized = value.lower().replace("ё", "е")
    normalized = re.sub(r"[^0-9a-zа-я]+", " ", normalized, flags=re.IGNORECASE)
    return re.sub(r"\s+", " ", normalized).strip()


def _extract_counterparty_name(transaction: BankTransaction) -> str:
    raw_payload = transaction.raw_payload or {}
    transfer = raw_payload.get("rurTransfer") if isinstance(raw_payload, dict) else None
    if not isinstance(transfer, dict):
        transfer = {}

    if transaction.direction == TransactionDirection.outgoing:
        direct_value = transfer.get("payeeName") or transaction.payer_name
    else:
        direct_value = transaction.payer_name or transfer.get("payerName") or transfer.get("payeeName")

    text = str(direct_value or "").strip()
    if not text:
        return ""

    parts = [part.strip() for part in text.split("//") if part.strip()]
    for part in parts:
        normalized = _normalize_name(part)
        if not normalized:
            continue
        if any(token in normalized for token in ("сбербанк", "россия", "область", "республика", "улица", "проспект")):
            continue
        if sum(ch.isdigit() for ch in part) > 3:
            continue
        if len(normalized.split()) >= 2:
            return normalized

    return _normalize_name(text)


def _names_match(left: str, right: str) -> bool:
    if not left or not right:
        return False
    if left == right or left in right or right in left:
        return True

    left_tokens = set(left.split())
    right_tokens = set(right.split())
    common_tokens = left_tokens & right_tokens
    return len(common_tokens) >= 2


def link_bank_return_transactions(session: Session) -> int:
    outgoing_transactions = session.scalars(
        select(BankTransaction).where(
            BankTransaction.direction == TransactionDirection.outgoing,
            BankTransaction.currency == "RUB",
            BankTransaction.deal_id.is_(None),
        )
    ).all()

    linked = 0
    for outgoing in outgoing_transactions:
        outgoing_counterparty = _extract_counterparty_name(outgoing)
        if not outgoing_counterparty:
            continue

        candidates: list[tuple[int, float, Deal]] = []
        deals = session.scalars(
            select(Deal).where(
                Deal.expected_fiat_amount == outgoing.amount,
                Deal.fiat_currency == outgoing.currency,
                Deal.completed_at.is_not(None),
                Deal.completed_at <= outgoing.booked_at,
                Deal.status.in_([DealStatus.matched, DealStatus.receipted, DealStatus.return_detected]),
            )
        ).all()

        for deal in deals:
            incoming_transactions = [tx for tx in deal.bank_transactions if tx.direction == TransactionDirection.incoming]
            if not incoming_transactions:
                continue

            latest_incoming = max(incoming_transactions, key=lambda tx: tx.booked_at)
            if outgoing.booked_at < latest_incoming.booked_at:
                continue
            if outgoing.booked_at - latest_incoming.booked_at > timedelta(days=14):
                continue

            incoming_counterparty = _extract_counterparty_name(latest_incoming)
            if not _names_match(incoming_counterparty, outgoing_counterparty):
                continue

            has_refund_receipt = any(receipt.receipt_type == ReceiptType.refund for receipt in deal.receipts)
            receipt_priority = 0 if has_refund_receipt else 1
            delta_seconds = abs((outgoing.booked_at - latest_incoming.booked_at).total_seconds())
            candidates.append((receipt_priority, delta_seconds, deal))

        if not candidates:
            continue

        candidates.sort(key=lambda item: item[:2])
        best_priority, best_delta, best_deal = candidates[0]
        if len(candidates) > 1 and candidates[1][:2] == (best_priority, best_delta):
            continue

        outgoing.deal_id = best_deal.id
        best_deal.status = DealStatus.return_detected
        best_deal.return_reason = best_deal.return_reason or "bank_return_same_counterparty"
        best_deal.return_detected_at = best_deal.return_detected_at or utc_now()
        classify_deal_status(best_deal)
        linked += 1

    session.commit()
    return linked


def classify_deal_status(deal: Deal) -> DealStatus:
    raw_payload = deal.raw_payload or {}
    ui_status = str(raw_payload.get("ui_status") or "").strip().lower()

    if any(
        receipt.receipt_type == ReceiptType.refund and receipt.status in {ReceiptStatus.issued, ReceiptStatus.pending}
        for receipt in deal.receipts
    ):
        deal.status = DealStatus.return_detected
        deal.return_reason = "refund_receipt"
        deal.return_detected_at = deal.return_detected_at or utc_now()
        return deal.status

    if raw_payload.get("is_return") or raw_payload.get("return_detected") or raw_payload.get("refund_detected"):
        deal.status = DealStatus.return_detected
        deal.return_reason = str(raw_payload.get("return_reason") or "payload_flag")
        deal.return_detected_at = deal.return_detected_at or utc_now()
        return deal.status

    if ui_status in RETURN_UI_STATUSES:
        deal.status = DealStatus.return_detected
        deal.return_reason = str(raw_payload.get("return_reason") or ui_status)
        deal.return_detected_at = deal.return_detected_at or utc_now()
        return deal.status

    if ui_status in REVIEW_UI_STATUSES and deal.status != DealStatus.return_detected:
        deal.status = DealStatus.third_party_review
        deal.return_reason = None
        deal.return_detected_at = None
        return deal.status

    if deal.status == DealStatus.return_detected:
        return deal.status

    sale_receipt_exists = any(
        receipt.receipt_type == ReceiptType.sale and receipt.status == ReceiptStatus.issued for receipt in deal.receipts
    )
    if sale_receipt_exists and deal.status == DealStatus.matched:
        deal.status = DealStatus.receipted

    return deal.status


def classify_all_deals(session: Session) -> int:
    deals = session.scalars(select(Deal)).all()
    for deal in deals:
        classify_deal_status(deal)
    session.commit()
    return len(deals)
