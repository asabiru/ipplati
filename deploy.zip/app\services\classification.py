from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Deal, DealStatus, FiscalReceipt, ReceiptStatus, ReceiptType


RETURN_UI_STATUSES = {
    "refund",
    "refunded",
    "returned",
    "reversed",
    "chargeback",
    "return_detected",
}

REVIEW_UI_STATUSES = {
    "disputed",
    "third_party_review",
}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def classify_deal_status(deal: Deal) -> DealStatus:
    raw_payload = deal.raw_payload or {}
    ui_status = str(raw_payload.get("ui_status") or "").strip().lower()

    if any(
        receipt.receipt_type == ReceiptType.refund and receipt.status in {ReceiptStatus.issued, ReceiptStatus.pending}
        for receipt in deal.receipts
    ):
        deal.status = DealStatus.return_detected
        deal.return_reason = "refund_receipt"
        deal.return_detected_at = deal.return_detected_at or utc_now()
        return deal.status

    if raw_payload.get("is_return") or raw_payload.get("return_detected") or raw_payload.get("refund_detected"):
        deal.status = DealStatus.return_detected
        deal.return_reason = str(raw_payload.get("return_reason") or "payload_flag")
        deal.return_detected_at = deal.return_detected_at or utc_now()
        return deal.status

    if ui_status in RETURN_UI_STATUSES:
        deal.status = DealStatus.return_detected
        deal.return_reason = str(raw_payload.get("return_reason") or ui_status)
        deal.return_detected_at = deal.return_detected_at or utc_now()
        return deal.status

    if ui_status in REVIEW_UI_STATUSES and deal.status != DealStatus.return_detected:
        deal.status = DealStatus.third_party_review
        deal.return_reason = None
        deal.return_detected_at = None
        return deal.status

    if deal.status == DealStatus.return_detected:
        return deal.status

    sale_receipt_exists = any(
        receipt.receipt_type == ReceiptType.sale and receipt.status == ReceiptStatus.issued for receipt in deal.receipts
    )
    if sale_receipt_exists and deal.status == DealStatus.matched:
        deal.status = DealStatus.receipted

    return deal.status


def classify_all_deals(session: Session) -> int:
    deals = session.scalars(select(Deal)).all()
    for deal in deals:
        classify_deal_status(deal)
    session.commit()
    return len(deals)
