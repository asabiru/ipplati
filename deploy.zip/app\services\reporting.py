from __future__ import annotations

from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import BankTransaction, Deal, DealStatus, TransactionDirection
from app.schemas import ReconciliationSummary


def build_reconciliation_summary(session: Session) -> ReconciliationSummary:
    total_deals = session.scalar(select(func.count()).select_from(Deal)) or 0
    matched_deals = session.scalar(select(func.count()).select_from(Deal).where(Deal.status == DealStatus.matched)) or 0
    receipted_deals = session.scalar(select(func.count()).select_from(Deal).where(Deal.status == DealStatus.receipted)) or 0
    return_detected_deals = session.scalar(
        select(func.count()).select_from(Deal).where(Deal.status == DealStatus.return_detected)
    ) or 0
    third_party_review_deals = session.scalar(
        select(func.count()).select_from(Deal).where(Deal.status == DealStatus.third_party_review)
    ) or 0
    unmatched_bank_transactions = session.scalar(
        select(func.count()).select_from(BankTransaction).where(BankTransaction.deal_id.is_(None))
    ) or 0

    total_expected_rub = session.scalar(select(func.coalesce(func.sum(Deal.expected_fiat_amount), 0)).where(Deal.fiat_currency == "RUB"))
    total_received_rub = session.scalar(
        select(func.coalesce(func.sum(BankTransaction.amount), 0)).where(
            BankTransaction.currency == "RUB",
            BankTransaction.direction == TransactionDirection.incoming,
        )
    )
    total_returned_rub = session.scalar(
        select(func.coalesce(func.sum(BankTransaction.amount), 0)).where(
            BankTransaction.currency == "RUB",
            BankTransaction.direction == TransactionDirection.outgoing,
        )
    )

    return ReconciliationSummary(
        total_deals=total_deals,
        matched_deals=matched_deals,
        receipted_deals=receipted_deals,
        return_detected_deals=return_detected_deals,
        third_party_review_deals=third_party_review_deals,
        unmatched_bank_transactions=unmatched_bank_transactions,
        total_expected_rub=Decimal(total_expected_rub or 0),
        total_received_rub=Decimal(total_received_rub or 0),
        total_returned_rub=Decimal(total_returned_rub or 0),
    )
