from __future__ import annotations

import argparse

from app.sync.config import sync_settings
from app.sync.daemon import AutoSyncDaemon


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Automatic synchronization for Wallet, Sber, and OFD")
    parser.add_argument("--api-base-url", default=sync_settings.api_base_url, help="Core API base URL")
    parser.add_argument(
        "--poll-interval",
        type=int,
        default=sync_settings.poll_interval_seconds,
        help="Polling interval in seconds",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    daemon = AutoSyncDaemon(api_base_url=args.api_base_url, poll_interval_seconds=args.poll_interval)
    daemon.run_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
