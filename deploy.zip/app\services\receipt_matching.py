from __future__ import annotations

from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Deal, DealStatus, FiscalReceipt, ReceiptStatus, ReceiptType
from app.services.classification import classify_deal_status


def reconcile_receipts(session: Session, window_hours: int = 24) -> int:
    receipts = session.scalars(select(FiscalReceipt).where(FiscalReceipt.deal_id.is_(None))).all()
    linked = 0
    for receipt in receipts:
        query = select(Deal).where(Deal.fiat_currency == "RUB", Deal.expected_fiat_amount == receipt.amount)
        window = timedelta(hours=window_hours)
        query = query.where(
            Deal.opened_at.is_not(None),
            Deal.opened_at >= receipt.issued_at - window,
            Deal.opened_at <= receipt.issued_at + window,
        ).order_by(Deal.opened_at.asc())

        candidates = session.scalars(query).all()
        for deal in candidates:
            if receipt.receipt_type == ReceiptType.sale and deal.status not in {
                DealStatus.canceled,
                DealStatus.return_detected,
            }:
                receipt.deal_id = deal.id
                deal.status = DealStatus.receipted if receipt.status == ReceiptStatus.issued else deal.status
                classify_deal_status(deal)
                linked += 1
                break

            if receipt.receipt_type == ReceiptType.refund:
                receipt.deal_id = deal.id
                deal.status = DealStatus.return_detected
                deal.return_reason = deal.return_reason or "refund_receipt_auto_match"
                classify_deal_status(deal)
                linked += 1
                break

    session.commit()
    return linked
