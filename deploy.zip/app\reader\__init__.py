"""Wallet reader package."""
