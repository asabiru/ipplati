from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from app.models import DealStatus, ReceiptStatus, ReceiptType, TransactionDirection


class WalletDealIn(BaseModel):
    external_id: str
    expected_fiat_amount: Decimal = Field(..., gt=0)
    fiat_currency: str = "RUB"
    counterparty_name: str | None = None
    counterparty_wallet_id: str | None = None
    payment_method: str | None = None
    opened_at: datetime | None = None
    completed_at: datetime | None = None
    status: DealStatus = DealStatus.detected
    notes: str | None = None
    raw_payload: dict[str, Any] = Field(default_factory=dict)


class WalletDealBatchIn(BaseModel):
    deals: list[WalletDealIn]


class BankTransactionIn(BaseModel):
    external_id: str
    amount: Decimal = Field(..., gt=0)
    currency: str = "RUB"
    direction: TransactionDirection = TransactionDirection.incoming
    payer_name: str | None = None
    payer_account_masked: str | None = None
    reference: str | None = None
    booked_at: datetime
    raw_payload: dict[str, Any] = Field(default_factory=dict)


class BankTransactionBatchIn(BaseModel):
    transactions: list[BankTransactionIn]


class ReceiptIn(BaseModel):
    external_id: str
    deal_external_id: str | None = None
    receipt_type: ReceiptType
    status: ReceiptStatus = ReceiptStatus.issued
    amount: Decimal = Field(..., gt=0)
    issued_at: datetime
    raw_payload: dict[str, Any] = Field(default_factory=dict)


class ReceiptBatchIn(BaseModel):
    receipts: list[ReceiptIn]


class MatchRunResult(BaseModel):
    deal_external_id: str
    bank_transaction_external_id: str | None = None
    score: int
    outcome: str
    rule_hits: dict[str, Any]


class DealOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    external_id: str
    source: str
    status: DealStatus
    fiat_currency: str
    expected_fiat_amount: Decimal
    counterparty_name: str | None
    counterparty_wallet_id: str | None
    payment_method: str | None
    opened_at: datetime | None
    completed_at: datetime | None
    return_reason: str | None
    return_detected_at: datetime | None
    notes: str | None
    raw_payload: dict[str, Any]
    created_at: datetime
    updated_at: datetime


class ReconciliationSummary(BaseModel):
    total_deals: int
    matched_deals: int
    receipted_deals: int
    return_detected_deals: int
    third_party_review_deals: int
    unmatched_bank_transactions: int
    total_expected_rub: Decimal
    total_received_rub: Decimal
    total_returned_rub: Decimal
