"""Wallet reader adapters."""
